
import { PdfChunk } from '../types';

// pdf.js is loaded from a CDN in index.html, so we need to declare its global variable.
declare const pdfjsLib: any;

export const processPdf = async (file: File): Promise<PdfChunk[]> => {
  const fileReader = new FileReader();

  return new Promise((resolve, reject) => {
    fileReader.onload = async (event) => {
      if (!event.target?.result) {
        return reject(new Error('Failed to read file.'));
      }
      
      const typedarray = new Uint8Array(event.target.result as ArrayBuffer);
      
      try {
        const pdf = await pdfjsLib.getDocument(typedarray).promise;
        const chunks: PdfChunk[] = [];
        
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          
          const pageText = textContent.items.map((item: any) => item.str).join(' ');
          
          if (pageText.trim()) {
            chunks.push({
              pageNumber: i,
              content: pageText,
            });
          }
        }
        resolve(chunks);
      } catch (error) {
        console.error('Error processing PDF:', error);
        reject(new Error('Could not parse the PDF file. It might be corrupted or protected.'));
      }
    };

    fileReader.onerror = (error) => {
      reject(error);
    };

    fileReader.readAsArrayBuffer(file);
  });
};