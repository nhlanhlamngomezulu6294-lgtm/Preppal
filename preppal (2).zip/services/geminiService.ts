
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiResponse, ChatMessage, PracticeQuestion, GlossaryTerm, Flashcard } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const qaResponseSchema = {
    type: Type.OBJECT,
    properties: {
        answer: { 
            type: Type.STRING, 
            description: "A concise answer synthesized from the source text. Use Markdown for lists." 
        },
        source: { 
            type: Type.STRING, 
            description: "The exact, unmodified quote from the textbook that supports your answer." 
        },
        pageNumber: { 
            type: Type.INTEGER, 
            description: "The integer page number where the source was found. Should be null if no source is found.",
            nullable: true
        },
    },
    required: ["answer", "source", "pageNumber"],
};

export const askQuestion = async (question: string, context: string, history: ChatMessage[]): Promise<GeminiResponse> => {
    const formattedHistory = history.length > 0
        ? history
            .map(msg => {
                if (msg.role === 'user') {
                    return `Previous Question: ${msg.content}`;
                } else {
                    let modelResponse = `Your Previous Answer: ${msg.content}`;
                    if (msg.source && msg.source.content) {
                        modelResponse += `\n(Source from Page ${msg.source.pageNumber}: "${msg.source.content}")`;
                    }
                    return modelResponse;
                }
            })
            .join('\n\n')
        : "No previous conversation history.";


    const prompt = `You are an expert AI assistant specialized in analyzing textbook content.
Your task is to answer a user's question based *exclusively* on the provided text from a textbook.
Do not use any external knowledge. You should also consider the conversation history for context if the user's question is a follow-up.

Here is the textbook content, with page numbers indicated:
---
${context}
---

Here is the recent conversation history:
---
${formattedHistory}
---

Current User's Question: "${question}"

Please follow these instructions precisely:
1.  Carefully read the textbook content to find the most relevant passage that answers the user's question, keeping in mind the conversation history for context.
2.  Your response must be a valid JSON object. Do not add any text before or after the JSON object.
3.  The JSON object must conform to the provided schema.
4.  For the 'answer' field: if your answer contains a list, format it using Markdown. Use hyphens (-) for unordered lists and numbers (e.g., 1., 2.) for ordered lists. Each list item must be on a new line.
5.  If the textbook content does not contain an answer to the question, respond with this specific JSON object:
    {
      "answer": "I could not find an answer to that question in the provided textbook.",
      "source": "",
      "pageNumber": null
    }
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: qaResponseSchema,
                temperature: 0.2,
            },
        });
        
        const jsonText = response.text.trim();
        const parsedResponse: GeminiResponse = JSON.parse(jsonText);
        
        return parsedResponse;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        return {
            answer: "An error occurred while communicating with the AI. Please check the console for details.",
            source: "",
            pageNumber: null,
        };
    }
};

const glossarySchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            term: { type: Type.STRING, description: "A key term or concept from the text." },
            definition: { type: Type.STRING, description: "A concise definition of the term, based strictly on the provided text." },
            pageNumber: { type: Type.INTEGER, description: "The page number where the term is primarily defined or discussed." }
        },
        required: ["term", "definition", "pageNumber"]
    }
};

export const generateGlossary = async (context: string): Promise<GlossaryTerm[]> => {
    const prompt = `You are an expert AI assistant. Your task is to analyze the provided textbook content and extract key terms and their definitions to build a glossary.

Follow these instructions:
1. Identify important terms, concepts, and key phrases from the text.
2. For each term, provide a clear and concise definition based *only* on the information in the textbook content.
3. Include the page number where the term is most relevantly defined or discussed.
4. Return the result as a JSON array of objects, conforming to the provided schema.
5. If no key terms can be identified, return an empty array.

Textbook Content:
---
${context}
---
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: glossarySchema,
                temperature: 0.1,
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating glossary:", error);
        throw new Error("Failed to generate glossary from the AI.");
    }
};


const practiceQuestionsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            type: { type: Type.STRING, enum: ["Multiple Choice", "Short Answer", "Essay"], description: "The type of question." },
            question: { type: Type.STRING, description: "The question text." },
            options: { type: Type.ARRAY, items: { type: Type.STRING }, description: "An array of 4-5 options for Multiple Choice questions.", nullable: true },
            answer: { type: Type.STRING, description: "The correct answer. For Multiple Choice, this is the text of the correct option. For others, it's the detailed answer." },
        },
        required: ["type", "question", "answer"]
    }
};

export const generatePracticeQuestions = async (context: string, focus: string): Promise<PracticeQuestion[]> => {
    const prompt = `You are an expert AI assistant designed to help students study. Your task is to generate practice questions based on the provided textbook content, with a specific focus.

Focus Area:
---
${focus}
---

Instructions:
1.  Generate a mix of question types: Multiple Choice, Short Answer, and Essay.
2.  All questions and answers must be based *exclusively* on the provided textbook content. Do not use external knowledge.
3.  The questions should be highly relevant to the specified 'Focus Area'.
4.  For 'Multiple Choice' questions, provide 4 distinct options and ensure the 'answer' field contains the full text of the correct option.
5.  For 'Short Answer' questions, the answer should be a concise paragraph.
6.  For 'Essay' questions, the answer should be a comprehensive summary of key points to be included in a full response.
7.  Return the result as a JSON array of objects, conforming to the provided schema.
8.  Generate between 5 to 10 high-quality questions.

Textbook Content (Source of Truth):
---
${context}
---
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: practiceQuestionsSchema,
                temperature: 0.5,
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating practice questions:", error);
        throw new Error("Failed to generate practice questions from the AI.");
    }
};

const flashcardSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            term: { type: Type.STRING, description: "The key term, concept, or question for the front of the flashcard." },
            definition: { type: Type.STRING, description: "The definition or answer for the back of the flashcard." },
            pageNumber: { type: Type.INTEGER, description: "The page number where this information is found." },
        },
        required: ["term", "definition", "pageNumber"]
    }
};

export const generateFlashcards = async (context: string, focus: string): Promise<Flashcard[]> => {
    const prompt = `You are an expert AI assistant designed to help students create study materials. Your task is to generate flashcards (term and definition pairs) based on the provided textbook content, with a specific focus.

Focus Area:
---
${focus}
---

Instructions:
1.  Identify key terms, important concepts, or main ideas from the textbook content that are relevant to the 'Focus Area'.
2.  For each identified item, create a flashcard object.
3.  The 'term' field should be the concept for the front of the card (e.g., "Mitochondria").
4.  The 'definition' field should be a concise explanation for the back of the card (e.g., "The powerhouse of the cell, responsible for generating ATP through cellular respiration.").
5.  All information must be derived *exclusively* from the provided textbook content. Do not use external knowledge.
6.  Include the 'pageNumber' where the information was found.
7.  Return the result as a JSON array of objects, conforming to the provided schema.
8.  Generate between 8 to 15 high-quality flashcards. If no relevant information is found, return an empty array.

Textbook Content (Source of Truth):
---
${context}
---
`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: flashcardSchema,
                temperature: 0.3,
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating flashcards:", error);
        throw new Error("Failed to generate flashcards from the AI.");
    }
};