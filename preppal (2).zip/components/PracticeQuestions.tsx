
import React, { useState, useCallback } from 'react';
import { PdfChunk, PracticeQuestion, ChatMessage } from '../types';
import { generatePracticeQuestions } from '../services/geminiService';
import { PracticeIcon, BookmarkSquareIcon, ChatBubbleOvalLeftEllipsisIcon, DocumentTextIcon } from './icons';
import StudyModePlaceholder from './StudyModePlaceholder';
import { AppMode } from '../App';

interface PracticeQuestionsProps {
  pdfTextChunks: PdfChunk[];
  messages: ChatMessage[];
  setMode: (mode: AppMode) => void;
}

type View = 'options' | 'loading' | 'results';

const PracticeQuestions: React.FC<PracticeQuestionsProps> = ({ pdfTextChunks, messages, setMode }) => {
  const [questions, setQuestions] = useState<PracticeQuestion[]>([]);
  const [view, setView] = useState<View>('options');
  const [error, setError] = useState<string | null>(null);
  const [visibleAnswers, setVisibleAnswers] = useState<Record<number, boolean>>({});

  // State for inputs
  const [chapterInput, setChapterInput] = useState('');
  const [startPageInput, setStartPageInput] = useState('');
  const [endPageInput, setEndPageInput] = useState('');
  
  if (pdfTextChunks.length === 0) {
    return (
      <StudyModePlaceholder
        icon={<PracticeIcon className="w-full h-full" />}
        title="Practice Questions"
        description="Test your knowledge by generating multiple choice, short answer, and essay questions based on the content of your textbook."
        onNavigateToQa={() => setMode('qa')}
      />
    );
  }

  const handleGeneration = useCallback(async (context: string, focus: string) => {
    setView('loading');
    setError(null);
    setQuestions([]);
    setVisibleAnswers({});

    try {
      const generatedQuestions = await generatePracticeQuestions(context, focus);
      setQuestions(generatedQuestions);
      setView('results');
    } catch (err) {
      setError('Failed to generate practice questions. Please try again.');
      console.error(err);
      setView('options'); // Go back to options on error
    }
  }, []);

  const handleGenerateByChapter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chapterInput.trim()) {
      setError("Please enter a chapter name or topic.");
      return;
    }
    const fullContext = pdfTextChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
    const focus = `The chapter titled or topic related to "${chapterInput}". The AI should first locate the relevant section(s) in the provided textbook content before generating questions.`;
    handleGeneration(fullContext, focus);
  };

  const handleGenerateByHistory = () => {
    const relevantHistory = messages.filter(m => m.role === 'user' || (m.role === 'model' && !m.isError));
    if (relevantHistory.length < 2) { // Need at least one Q&A pair
      setError("Not enough Q&A history available to generate questions.");
      return;
    }
    const historyString = relevantHistory.map(m => `${m.role === 'user' ? 'User asked' : 'You answered'}: ${m.content}`).join('\n');
    const fullContext = pdfTextChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
    const focus = `The concepts and topics discussed in the following conversation history:\n${historyString}`;
    handleGeneration(fullContext, focus);
  };

  const handleGenerateByPages = (e: React.FormEvent) => {
    e.preventDefault();
    const start = parseInt(startPageInput, 10);
    const end = parseInt(endPageInput, 10);

    if (isNaN(start) || isNaN(end) || start <= 0 || end < start) {
      setError("Please enter valid page numbers (e.g., from 5 to 10).");
      return;
    }

    const pageChunks = pdfTextChunks.filter(c => c.pageNumber >= start && c.pageNumber <= end);
    if (pageChunks.length === 0) {
      setError(`No text content found between pages ${start} and ${end}.`);
      return;
    }

    const context = pageChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
    const focus = `The content from pages ${start} to ${end}.`;
    handleGeneration(context, focus);
  };
  
  const toggleAnswer = (index: number) => {
    setVisibleAnswers(prev => ({...prev, [index]: !prev[index]}));
  };

  const renderQuestion = (q: PracticeQuestion, index: number) => {
    const isAnswerVisible = visibleAnswers[index];
    return (
        <div key={index} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-[#008080] mb-2">{q.type}</h3>
            <p className="text-lg text-[#2C2C2C] mb-4">{q.question}</p>
            {q.type === 'Multiple Choice' && q.options && (
                <div className="space-y-2 mb-4">
                    {q.options.map((opt, i) => <div key={i} className="bg-gray-100 p-3 rounded-md text-gray-700">{opt}</div>)}
                </div>
            )}
            <div className="mt-4">
                <button
                    onClick={() => toggleAnswer(index)}
                    className="text-[#008080] font-semibold hover:text-teal-700 transition-colors"
                >
                    {isAnswerVisible ? 'Hide' : 'Show'} Answer
                </button>
                {isAnswerVisible && (
                    <div className="mt-3 bg-gray-50 p-4 rounded-md border-l-4 border-teal-400">
                        <p className="text-gray-700 whitespace-pre-wrap font-mono text-sm">{q.answer}</p>
                    </div>
                )}
            </div>
        </div>
    );
  };

  const renderOptionsView = () => (
    <div className="w-full max-w-4xl mx-auto">
        <div className="text-center mb-10">
            <h3 className="text-2xl font-bold text-[#2C2C2C] mb-2">Test Your Knowledge</h3>
            <p className="text-gray-600">Choose how you want to generate practice questions from your document.</p>
        </div>

        {error && <div className="bg-red-100 border border-red-300 text-red-700 p-3 rounded-md mb-6" role="alert">{error}</div>}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Option 1: By Chapter */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-3">
                    <BookmarkSquareIcon className="w-7 h-7 text-[#008080]" />
                    <h4 className="text-lg font-semibold text-[#2C2C2C]">From a Chapter</h4>
                </div>
                <p className="text-sm text-gray-600 flex-grow mb-4">Enter a chapter title or topic to focus the questions.</p>
                <form onSubmit={handleGenerateByChapter} className="mt-auto">
                    <input
                        type="text"
                        value={chapterInput}
                        onChange={e => setChapterInput(e.target.value)}
                        placeholder="e.g., 'Chapter 3: Mitosis'"
                        className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-sm mb-3 focus:ring-[#008080] focus:border-[#008080]"
                        aria-label="Chapter or topic name"
                    />
                    <button type="submit" className="w-full bg-[#008080] text-white font-semibold py-2 px-4 rounded-md hover:bg-teal-700 transition-colors">
                        Generate
                    </button>
                </form>
            </div>

            {/* Option 2: By History */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-3">
                    <ChatBubbleOvalLeftEllipsisIcon className="w-7 h-7 text-[#008080]" />
                    <h4 className="text-lg font-semibold text-[#2C2C2C]">From Q&A History</h4>
                </div>
                <p className="text-sm text-gray-600 flex-grow mb-4">Create questions based on the concepts from your chat session.</p>
                <button onClick={handleGenerateByHistory} className="w-full bg-[#008080] text-white font-semibold py-2 px-4 rounded-md hover:bg-teal-700 transition-colors mt-auto">
                    Generate
                </button>
            </div>

            {/* Option 3: By Pages */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-3">
                    <DocumentTextIcon className="w-7 h-7 text-[#008080]" />
                    <h4 className="text-lg font-semibold text-[#2C2C2C]">From Page Range</h4>
                </div>
                <p className="text-sm text-gray-600 flex-grow mb-4">Target specific pages in the textbook for your questions.</p>
                <form onSubmit={handleGenerateByPages} className="mt-auto">
                    <div className="flex items-center gap-2 mb-3">
                         <input
                            type="number"
                            value={startPageInput}
                            onChange={e => setStartPageInput(e.target.value)}
                            placeholder="Start"
                            className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-[#008080] focus:border-[#008080]"
                            aria-label="Start page"
                        />
                         <span className="text-gray-500">-</span>
                         <input
                            type="number"
                            value={endPageInput}
                            onChange={e => setEndPageInput(e.target.value)}
                            placeholder="End"
                            className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-[#008080] focus:border-[#008080]"
                            aria-label="End page"
                        />
                    </div>
                    <button type="submit" className="w-full bg-[#008080] text-white font-semibold py-2 px-4 rounded-md hover:bg-teal-700 transition-colors">
                        Generate
                    </button>
                </form>
            </div>
        </div>
    </div>
  );

  const renderLoadingView = () => (
    <div className="flex flex-col items-center justify-center p-8 text-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#008080]"></div>
        <p className="mt-4 text-lg text-gray-700">Generating insightful questions...</p>
        <p className="text-sm text-gray-500">This may take a moment.</p>
    </div>
  );

  const renderResultsView = () => (
    <>
        {questions.length > 0 ? (
            <div className="space-y-6">
                <div className="flex justify-end">
                    <button 
                        onClick={() => {
                            setView('options');
                            setError(null);
                            setQuestions([]);
                        }}
                        className="bg-white border border-[#008080] hover:bg-teal-50 text-[#008080] font-bold py-2 px-4 rounded-lg transition-colors duration-200"
                    >
                        Generate New Questions
                    </button>
                </div>
                {questions.map(renderQuestion)}
            </div>
        ) : (
             <div className="text-center py-16">
                <h3 className="text-2xl font-bold text-[#2C2C2C] mb-2">No Questions Generated</h3>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">The AI couldn't generate questions based on your request. This might happen if the content is sparse or the topic isn't found.</p>
                <button 
                    onClick={() => setView('options')}
                    className="bg-[#008080] hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
                >
                    Try Again
                </button>
            </div>
        )}
    </>
  );

  return (
    <div className="flex flex-col w-full h-full">
      <div className="p-4 bg-white rounded-t-lg border border-gray-200 border-b-0 flex items-center gap-3">
        <PracticeIcon className="w-6 h-6 text-[#008080]" />
        <h2 className="font-semibold text-lg text-[#2C2C2C]">Practice Questions</h2>
      </div>
      
      <div className="flex-grow p-6 overflow-y-auto bg-white rounded-b-lg border border-gray-200 border-t-0">
        {view === 'loading' && renderLoadingView()}
        {view === 'options' && renderOptionsView()}
        {view === 'results' && renderResultsView()}
      </div>
    </div>
  );
};

export default PracticeQuestions;