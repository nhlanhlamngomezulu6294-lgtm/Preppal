
import React from 'react';
import { ChatMessage } from '../types';
import { UserIcon, BotIcon, QuoteIcon } from './icons';

interface MessageProps {
  message: ChatMessage;
}

const FormattedContent: React.FC<{ text: string }> = ({ text }) => {
  const elements: JSX.Element[] = [];
  let listItems: JSX.Element[] = [];
  let listType: 'ul' | 'ol' | null = null;

  const flushList = () => {
    if (listItems.length > 0) {
      if (listType === 'ul') {
        elements.push(<ul key={`ul-${elements.length}`} className="list-disc list-outside space-y-1 pl-5 my-2">{listItems}</ul>);
      } else if (listType === 'ol') {
        elements.push(<ol key={`ol-${elements.length}`} className="list-decimal list-outside space-y-1 pl-5 my-2">{listItems}</ol>);
      }
      listItems = []; // Clear the array
      listType = null;
    }
  };

  text.split('\n').forEach((line, index) => {
    const ulMatch = line.match(/^\s*[\*\-]\s(.*)/);
    const olMatch = line.match(/^\s*(\d+)\.\s(.*)/);

    if (ulMatch) {
      if (listType !== 'ul') {
        flushList();
      }
      listType = 'ul';
      listItems.push(<li key={`li-${index}`}>{ulMatch[1]}</li>);
    } else if (olMatch) {
      if (listType !== 'ol') {
        flushList();
      }
      listType = 'ol';
      listItems.push(<li key={`li-${index}`}>{olMatch[1]}</li>);
    } else {
      flushList();
      if (line.trim().length > 0) {
        elements.push(<div key={`p-${index}`}>{line}</div>);
      }
    }
  });

  flushList(); // Flush any remaining list items at the end

  return <>{elements}</>;
};

const Message: React.FC<MessageProps> = ({ message }) => {
  const { role, content, source, isError } = message;
  const isUser = role === 'user';

  const containerClasses = isUser ? 'justify-end' : 'justify-start';
  const bubbleClasses = isUser
    ? 'bg-[#008080] text-white rounded-br-none'
    : isError 
    ? 'bg-red-100 text-red-900 border border-red-200 rounded-bl-none'
    : 'bg-gray-100 text-[#2C2C2C] rounded-bl-none';
  const Icon = isUser ? UserIcon : BotIcon;

  return (
    <div className={`flex items-start gap-3 ${containerClasses}`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0 mt-1">
          <Icon className="w-5 h-5 text-gray-600" />
        </div>
      )}
      <div className="flex flex-col" style={{maxWidth: 'calc(100% - 44px)'}}>
        <div className={`rounded-lg p-4 ${bubbleClasses} max-w-xl break-words`}>
          {isUser ? content : <FormattedContent text={content} />}
        </div>
        {source && source.content && (
          <div className="mt-3 border-l-4 border-teal-300 pl-4 py-2 bg-gray-50 rounded-r-lg max-w-xl">
            <div className="flex items-center text-sm text-gray-600 mb-2">
              <QuoteIcon className="w-4 h-4 mr-2" />
              <span>Source from Page {source.pageNumber}</span>
            </div>
            <blockquote className="text-gray-700 italic">
              "{source.content}"
            </blockquote>
          </div>
        )}
      </div>
       {isUser && (
        <div className="w-8 h-8 rounded-full bg-[#008080] flex items-center justify-center flex-shrink-0 mt-1">
          <Icon className="w-5 h-5 text-white" />
        </div>
      )}
    </div>
  );
};

export default Message;