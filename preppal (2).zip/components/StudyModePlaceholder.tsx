
import React from 'react';

interface StudyModePlaceholderProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onNavigateToQa: () => void;
}

const StudyModePlaceholder: React.FC<StudyModePlaceholderProps> = ({ icon, title, description, onNavigateToQa }) => {
  return (
    <div className="flex flex-col w-full h-full bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden items-center justify-center text-center p-6">
      <div className="w-16 h-16 text-gray-300 mb-4">{icon}</div>
      <h2 className="text-3xl font-bold text-[#2C2C2C] mb-2">{title}</h2>
      <p className="text-gray-600 max-w-md mb-6">{description}</p>
      <p className="text-gray-500 mb-8">Please upload a textbook to get started.</p>
      <button
        onClick={onNavigateToQa}
        className="bg-[#008080] hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
      >
        Go to Q&A to Upload
      </button>
    </div>
  );
};

export default StudyModePlaceholder;