
import React, { useCallback, useState } from 'react';
import { PlusIcon, MicrophoneIcon, TuningIcon } from './icons';

interface FileUploadProps {
  onFileUpload: (file: File) => void;
  isLoading: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload, isLoading }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileUpload(e.target.files[0]);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      if (e.dataTransfer.files[0].type === 'application/pdf') {
        onFileUpload(e.dataTransfer.files[0]);
      }
    }
  }, [onFileUpload]);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  return (
    <div 
      className={`w-full h-full flex flex-col items-center justify-center text-center transition-colors duration-300 ${isDragging ? 'bg-teal-50' : 'bg-transparent'}`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
    >
      {isLoading ? (
        <div className="flex flex-col items-center justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#008080]"></div>
          <p className="mt-4 text-lg text-gray-700">Processing your PDF...</p>
          <p className="text-sm text-gray-500">This may take a moment for large documents.</p>
        </div>
      ) : (
        <div className="w-full max-w-2xl px-4">
          <h2 className="text-4xl sm:text-5xl font-medium text-gray-700 mb-8 leading-tight">
            Hi there, ready for the session?, lets get started
          </h2>
          <div className="relative">
             <input
              type="file"
              id="file-upload"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleFileChange}
              accept=".pdf"
            />
            <label htmlFor="file-upload" className="flex items-center w-full bg-white rounded-full shadow-lg border border-gray-200 p-2 pr-3 cursor-pointer hover:shadow-xl transition-shadow duration-300">
              <span className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors ml-1" aria-hidden="true">
                 <PlusIcon className="w-6 h-6 text-gray-600" />
              </span>
              <span className="text-lg text-gray-400 ml-4 flex-grow text-left">Upload your textbook...</span>
              <div className="flex items-center space-x-1 sm:space-x-2">
                <button className="p-2 rounded-full hover:bg-gray-100 transition-colors" disabled aria-label="Use microphone">
                  <MicrophoneIcon className="w-6 h-6 text-gray-500" />
                </button>
                <button className="p-2 rounded-full hover:bg-gray-100 transition-colors" disabled aria-label="Settings">
                  <TuningIcon className="w-6 h-6 text-gray-500" />
                </button>
              </div>
            </label>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;