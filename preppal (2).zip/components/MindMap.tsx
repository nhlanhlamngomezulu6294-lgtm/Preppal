
import React from 'react';
import { MindmapIcon } from './icons';
import { AppMode } from '../App';
import { PdfChunk } from '../types';

interface MindMapProps {
  pdfTextChunks: PdfChunk[];
  setMode: (mode: AppMode) => void;
}

const MindMap: React.FC<MindMapProps> = ({ pdfTextChunks, setMode }) => {
  const isPdfLoaded = pdfTextChunks.length > 0;
  
  return (
    <div className="flex flex-col w-full h-full bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden items-center justify-center text-center p-6">
        <MindmapIcon className="w-16 h-16 text-gray-300 mb-4" />
        <h2 className="text-3xl font-bold text-[#2C2C2C] mb-2">Concept Map Generation is Coming Soon!</h2>
        <p className="text-gray-600 max-w-md">
            For all the visual learners out there, we're working on a feature to automatically generate mind maps and concept maps to help you connect the dots between topics.
        </p>
        {!isPdfLoaded && (
          <div className='mt-6'>
            <p className="text-gray-500 mb-8">Please upload a textbook to get started.</p>
            <button
              onClick={() => setMode('qa')}
              className="bg-[#008080] hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
            >
              Go to Q&A to Upload
            </button>
          </div>
        )}
    </div>
  );
};

export default MindMap;