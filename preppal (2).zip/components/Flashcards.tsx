
import React, { useState, useCallback } from 'react';
import { PdfChunk, Flashcard, ChatMessage } from '../types';
import { generateFlashcards } from '../services/geminiService';
import { FlashcardIcon, BookmarkSquareIcon, ChatBubbleOvalLeftEllipsisIcon, DocumentTextIcon, ArrowPathIcon } from './icons';
import StudyModePlaceholder from './StudyModePlaceholder';
import { AppMode } from '../App';

interface FlashcardsProps {
  pdfTextChunks: PdfChunk[];
  messages: ChatMessage[];
  setMode: (mode: AppMode) => void;
}

type View = 'options' | 'loading' | 'results';

const Flashcards: React.FC<FlashcardsProps> = ({ pdfTextChunks, messages, setMode }) => {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [view, setView] = useState<View>('options');
  const [error, setError] = useState<string | null>(null);
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});

  // State for inputs
  const [chapterInput, setChapterInput] = useState('');
  const [startPageInput, setStartPageInput] = useState('');
  const [endPageInput, setEndPageInput] = useState('');

  if (pdfTextChunks.length === 0) {
    return (
      <StudyModePlaceholder
        icon={<FlashcardIcon className="w-full h-full" />}
        title="Flashcards"
        description="Create interactive flashcard decks from specific chapters, page ranges, or your Q&A history to memorize key concepts."
        onNavigateToQa={() => setMode('qa')}
      />
    );
  }
  
  const handleGeneration = useCallback(async (context: string, focus: string) => {
    setView('loading');
    setError(null);
    setFlashcards([]);
    setFlippedCards({});

    try {
      const generatedFlashcards = await generateFlashcards(context, focus);
      setFlashcards(generatedFlashcards);
      setView('results');
    } catch (err) {
      setError('Failed to generate flashcards. Please try again.');
      console.error(err);
      setView('options');
    }
  }, []);

  const handleGenerateByChapter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chapterInput.trim()) {
      setError("Please enter a chapter name or topic.");
      return;
    }
    const fullContext = pdfTextChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
    const focus = `The chapter titled or topic related to "${chapterInput}". The AI should first locate the relevant section(s) in the provided textbook content before generating flashcards.`;
    handleGeneration(fullContext, focus);
  };

  const handleGenerateByHistory = () => {
    const relevantHistory = messages.filter(m => m.role === 'user' || (m.role === 'model' && !m.isError));
    if (relevantHistory.length < 2) {
      setError("Not enough Q&A history available to generate flashcards.");
      return;
    }
    const historyString = relevantHistory.map(m => `${m.role === 'user' ? 'User asked' : 'You answered'}: ${m.content}`).join('\n');
    const fullContext = pdfTextChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
    const focus = `The concepts and topics discussed in the following conversation history:\n${historyString}`;
    handleGeneration(fullContext, focus);
  };

  const handleGenerateByPages = (e: React.FormEvent) => {
    e.preventDefault();
    const start = parseInt(startPageInput, 10);
    const end = parseInt(endPageInput, 10);

    if (isNaN(start) || isNaN(end) || start <= 0 || end < start) {
      setError("Please enter valid page numbers (e.g., from 5 to 10).");
      return;
    }

    const pageChunks = pdfTextChunks.filter(c => c.pageNumber >= start && c.pageNumber <= end);
    if (pageChunks.length === 0) {
      setError(`No text content found between pages ${start} and ${end}.`);
      return;
    }

    const context = pageChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
    const focus = `The content from pages ${start} to ${end}.`;
    handleGeneration(context, focus);
  };

  const toggleFlip = (index: number) => {
    setFlippedCards(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const renderOptionsView = () => (
    <div className="w-full max-w-4xl mx-auto">
        <div className="text-center mb-10">
            <h3 className="text-2xl font-bold text-[#2C2C2C] mb-2">Create Your Flashcard Deck</h3>
            <p className="text-gray-600">Choose how you want to generate flashcards from your document.</p>
        </div>

        {error && <div className="bg-red-100 border border-red-300 text-red-700 p-3 rounded-md mb-6" role="alert">{error}</div>}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-3">
                    <BookmarkSquareIcon className="w-7 h-7 text-[#008080]" />
                    <h4 className="text-lg font-semibold text-[#2C2C2C]">From a Chapter</h4>
                </div>
                <p className="text-sm text-gray-600 flex-grow mb-4">Enter a chapter title or topic to focus the flashcards.</p>
                <form onSubmit={handleGenerateByChapter} className="mt-auto">
                    <input
                        type="text"
                        value={chapterInput}
                        onChange={e => setChapterInput(e.target.value)}
                        placeholder="e.g., 'Chapter 3: Mitosis'"
                        className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-sm mb-3 focus:ring-[#008080] focus:border-[#008080]"
                        aria-label="Chapter or topic name"
                    />
                    <button type="submit" className="w-full bg-[#008080] text-white font-semibold py-2 px-4 rounded-md hover:bg-teal-700 transition-colors">
                        Generate
                    </button>
                </form>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-3">
                    <ChatBubbleOvalLeftEllipsisIcon className="w-7 h-7 text-[#008080]" />
                    <h4 className="text-lg font-semibold text-[#2C2C2C]">From Q&A History</h4>
                </div>
                <p className="text-sm text-gray-600 flex-grow mb-4">Create flashcards based on the concepts from your chat session.</p>
                <button onClick={handleGenerateByHistory} className="w-full bg-[#008080] text-white font-semibold py-2 px-4 rounded-md hover:bg-teal-700 transition-colors mt-auto">
                    Generate
                </button>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 flex flex-col">
                <div className="flex items-center gap-3 mb-3">
                    <DocumentTextIcon className="w-7 h-7 text-[#008080]" />
                    <h4 className="text-lg font-semibold text-[#2C2C2C]">From Page Range</h4>
                </div>
                <p className="text-sm text-gray-600 flex-grow mb-4">Target specific pages in the textbook for your flashcards.</p>
                <form onSubmit={handleGenerateByPages} className="mt-auto">
                    <div className="flex items-center gap-2 mb-3">
                         <input
                            type="number"
                            value={startPageInput}
                            onChange={e => setStartPageInput(e.target.value)}
                            placeholder="Start"
                            className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-[#008080] focus:border-[#008080]"
                            aria-label="Start page"
                        />
                         <span className="text-gray-500">-</span>
                         <input
                            type="number"
                            value={endPageInput}
                            onChange={e => setEndPageInput(e.target.value)}
                            placeholder="End"
                            className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-[#008080] focus:border-[#008080]"
                            aria-label="End page"
                        />
                    </div>
                    <button type="submit" className="w-full bg-[#008080] text-white font-semibold py-2 px-4 rounded-md hover:bg-teal-700 transition-colors">
                        Generate
                    </button>
                </form>
            </div>
        </div>
    </div>
  );
  
  const renderLoadingView = () => (
    <div className="flex flex-col items-center justify-center p-8 text-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#008080]"></div>
        <p className="mt-4 text-lg text-gray-700">Generating your flashcard deck...</p>
        <p className="text-sm text-gray-500">This may take a moment.</p>
    </div>
  );
  
  const renderResultsView = () => (
    <>
        {flashcards.length > 0 ? (
            <div>
                 <div className="flex justify-end mb-6">
                    <button 
                        onClick={() => {
                            setView('options');
                            setError(null);
                            setFlashcards([]);
                        }}
                        className="bg-white border border-[#008080] hover:bg-teal-50 text-[#008080] font-bold py-2 px-4 rounded-lg transition-colors duration-200"
                    >
                        Generate New Deck
                    </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {flashcards.map((card, index) => (
                        <div key={index} className="perspective-1000">
                            <div 
                                className={`relative w-full h-64 rounded-lg shadow-md transition-transform duration-700 transform-style-3d cursor-pointer ${flippedCards[index] ? 'rotate-y-180' : ''}`}
                                onClick={() => toggleFlip(index)}
                            >
                                {/* Front of Card */}
                                <div className="absolute w-full h-full backface-hidden bg-white border-2 border-teal-400 rounded-lg p-4 flex flex-col justify-center items-center text-center">
                                    <p className="text-lg font-semibold text-[#2C2C2C]">{card.term}</p>
                                    <div className="absolute bottom-2 right-2 flex items-center gap-1 text-xs text-teal-400">
                                        <ArrowPathIcon className="w-4 h-4" />
                                        <span>Flip</span>
                                    </div>
                                </div>
                                {/* Back of Card */}
                                <div className="absolute w-full h-full backface-hidden bg-[#008080] text-white rounded-lg p-4 flex flex-col justify-center items-center text-center rotate-y-180">
                                    <p className="text-sm">{card.definition}</p>
                                    <span className="absolute bottom-2 left-2 text-xs font-mono text-teal-200">p. {card.pageNumber}</span>
                                    <div className="absolute bottom-2 right-2 flex items-center gap-1 text-xs text-teal-200">
                                        <ArrowPathIcon className="w-4 h-4" />
                                        <span>Flip</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                <style>{`
                    .perspective-1000 { perspective: 1000px; }
                    .transform-style-3d { transform-style: preserve-3d; }
                    .rotate-y-180 { transform: rotateY(180deg); }
                    .backface-hidden { backface-visibility: hidden; }
                `}</style>
            </div>
        ) : (
            <div className="text-center py-16">
                <h3 className="text-2xl font-bold text-[#2C2C2C] mb-2">No Flashcards Generated</h3>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">The AI couldn't create flashcards for your request. This might happen if the content is sparse or the topic isn't found.</p>
                <button 
                    onClick={() => setView('options')}
                    className="bg-[#008080] hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
                >
                    Try Again
                </button>
            </div>
        )}
    </>
  );

  return (
    <div className="flex flex-col w-full h-full">
      <div className="p-4 bg-white rounded-t-lg border border-gray-200 border-b-0 flex items-center gap-3">
        <FlashcardIcon className="w-6 h-6 text-[#008080]" />
        <h2 className="font-semibold text-lg text-[#2C2C2C]">Flashcards</h2>
      </div>
      
      <div className="flex-grow p-6 overflow-y-auto bg-white rounded-b-lg border border-gray-200 border-t-0">
        {view === 'loading' && renderLoadingView()}
        {view === 'options' && renderOptionsView()}
        {view === 'results' && renderResultsView()}
      </div>
    </div>
  );
};

export default Flashcards;