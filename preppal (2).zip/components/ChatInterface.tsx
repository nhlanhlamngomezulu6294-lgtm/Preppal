
import React, { useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import Message from './Message';
import { BookOpenIcon } from './icons';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  isAnswering: boolean;
  fileName: string;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isAnswering, fileName }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  return (
    <div className="flex flex-col w-full h-full bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
      <div className="p-4 bg-white border-b border-gray-200 flex items-center gap-3">
        <BookOpenIcon className="w-6 h-6 text-[#008080]" />
        <p className="font-medium text-gray-600 truncate">
          Currently analyzing: <span className="font-semibold text-[#2C2C2C]">{fileName}</span>
        </p>
      </div>

      <div className="flex-grow p-6 overflow-y-auto space-y-6">
        {messages.map((msg, index) => (
          <Message key={index} message={msg} />
        ))}
        {isAnswering && (
          <div className="flex justify-start">
             <div className="bg-gray-200 rounded-lg p-4 max-w-xl">
                 <div className="flex items-center space-x-2">
                     <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse"></div>
                     <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                     <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                 </div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default ChatInterface;