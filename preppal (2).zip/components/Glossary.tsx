
import React, { useState, useCallback, useMemo } from 'react';
import { PdfChunk, GlossaryTerm } from '../types';
import { generateGlossary } from '../services/geminiService';
import { GlossaryIcon } from './icons';
import StudyModePlaceholder from './StudyModePlaceholder';
import { AppMode } from '../App';

interface GlossaryProps {
  pdfTextChunks: PdfChunk[];
  setMode: (mode: AppMode) => void;
}

const Glossary: React.FC<GlossaryProps> = ({ pdfTextChunks, setMode }) => {
  const [terms, setTerms] = useState<GlossaryTerm[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  if (pdfTextChunks.length === 0) {
    return (
      <StudyModePlaceholder
        icon={<GlossaryIcon className="w-full h-full" />}
        title="Glossary"
        description="Automatically extract and define key terms from your document to create a powerful study guide."
        onNavigateToQa={() => setMode('qa')}
      />
    );
  }

  const handleGenerateGlossary = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setTerms([]);

    try {
      const context = pdfTextChunks.map(c => `Page ${c.pageNumber}:\n${c.content}`).join('\n\n---\n\n');
      const generatedTerms = await generateGlossary(context);
      generatedTerms.sort((a, b) => a.term.localeCompare(b.term));
      setTerms(generatedTerms);
    } catch (err) {
      setError('Failed to generate the glossary. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [pdfTextChunks]);

  const filteredTerms = useMemo(() => {
    if (!searchTerm) return terms;
    return terms.filter(
      term =>
        term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
        term.definition.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [terms, searchTerm]);

  return (
    <div className="flex flex-col w-full h-full bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
      <div className="p-4 bg-white border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <GlossaryIcon className="w-6 h-6 text-[#008080]" />
          <h2 className="font-semibold text-lg text-[#2C2C2C]">Glossary of Key Terms</h2>
        </div>
        {terms.length > 0 && (
          <input
            type="text"
            placeholder="Search terms..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full sm:w-64 bg-white border border-gray-300 text-[#2C2C2C] placeholder-gray-500/60 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#008080] focus:border-[#008080] transition"
          />
        )}
      </div>

      <div className="flex-grow p-6 overflow-y-auto">
        {isLoading && (
            <div className="flex flex-col items-center justify-center p-8 text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#008080]"></div>
                <p className="mt-4 text-lg text-gray-700">Extracting key terms...</p>
                <p className="text-sm text-gray-500">This might take a moment.</p>
            </div>
        )}
        {error && <div className="bg-red-100 border border-red-300 text-red-700 p-3 rounded-md">{error}</div>}

        {!isLoading && terms.length === 0 && !error && (
            <div className="text-center py-16">
                <h3 className="text-2xl font-bold text-[#2C2C2C] mb-2">Build Your Glossary</h3>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">Automatically extract and define key terms from your document to create a powerful study guide.</p>
                <button 
                    onClick={handleGenerateGlossary}
                    className="bg-[#008080] hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
                >
                    Generate Glossary
                </button>
            </div>
        )}

        {filteredTerms.length > 0 && (
          <dl className="space-y-6">
            {filteredTerms.map((term, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <dt className="text-lg font-bold text-[#008080] flex justify-between items-baseline">
                  <span>{term.term}</span>
                  <span className="text-xs font-mono text-gray-500/70">p. {term.pageNumber}</span>
                </dt>
                <dd className="mt-1 text-gray-700">{term.definition}</dd>
              </div>
            ))}
          </dl>
        )}

        {!isLoading && terms.length > 0 && filteredTerms.length === 0 && (
          <div className="text-center py-10">
            <p className="text-lg text-gray-500">No terms found matching your search.</p>
          </div>
        )}

      </div>
    </div>
  );
};

export default Glossary;