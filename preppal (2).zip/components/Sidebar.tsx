
import React from 'react';
import { AppMode } from '../App';
import { ChatIcon, PracticeIcon, GlossaryIcon, FlashcardIcon, MindmapIcon, OfflineIcon, ChevronDoubleLeftIcon } from './icons';

interface SidebarProps {
  currentMode: AppMode;
  setMode: (mode: AppMode) => void;
  isPdfLoaded: boolean;
  isCollapsed: boolean;
  setIsCollapsed: (isCollapsed: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentMode, setMode, isPdfLoaded, isCollapsed, setIsCollapsed }) => {
  const navItems = [
    { id: 'qa', label: 'Q&A', icon: ChatIcon },
    { id: 'practice', label: 'Practice Questions', icon: PracticeIcon },
    { id: 'glossary', label: 'Glossary', icon: GlossaryIcon },
    { id: 'flashcards', label: 'Flashcards', icon: FlashcardIcon },
    { id: 'mindmap', label: 'Mind Map', icon: MindmapIcon },
  ] as const;

  return (
    <nav className={`bg-white p-2 flex flex-col justify-between transition-all duration-300 ease-in-out flex-shrink-0 border-r border-gray-200 ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <div>
        {!isCollapsed && (
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4 px-4 pt-2">Study Modes</h2>
        )}
        <ul className="space-y-2">
          {navItems.map(item => (
            <li key={item.id}>
              <button
                onClick={() => setMode(item.id)}
                title={item.label}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-md text-left transition-colors duration-200 ${
                  isCollapsed ? 'justify-center' : ''
                } ${
                  currentMode === item.id
                    ? 'bg-teal-100 text-[#008080] font-semibold'
                    : 'text-[#2C2C2C] hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-6 h-6 flex-shrink-0" />
                {!isCollapsed && <span>{item.label}</span>}
              </button>
            </li>
          ))}
        </ul>
      </div>
       <div>
         <div className="border-t border-gray-200 my-2"></div>
         <div 
            className={`w-full flex items-center gap-3 px-4 py-2 rounded-md text-left text-gray-400 cursor-not-allowed ${isCollapsed ? 'justify-center' : ''}`} 
            title="Offline Mode: Coming Soon!"
        >
            <OfflineIcon className="w-6 h-6 flex-shrink-0" />
            {!isCollapsed && <span>Offline Mode</span>}
         </div>
         <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className={`w-full flex items-center gap-3 px-4 py-2 rounded-md text-left text-gray-600 hover:bg-gray-100 transition-colors duration-200 ${isCollapsed ? 'justify-center' : ''}`}
            title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            <ChevronDoubleLeftIcon className={`w-6 h-6 flex-shrink-0 transition-transform duration-300 ${isCollapsed && 'rotate-180'}`} />
            {!isCollapsed && <span>Collapse</span>}
        </button>
       </div>
    </nav>
  );
};

export default Sidebar;